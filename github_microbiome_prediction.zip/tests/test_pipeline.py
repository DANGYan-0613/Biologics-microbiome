import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import prediction_pipeline as pipeline
import diagnostics


def synthetic_tables(directory):
    rng = np.random.default_rng(31)
    datasets = [dataset for values in pipeline.GROUPS.values() for dataset in values]
    rows = []
    for dataset_index, dataset in enumerate(datasets):
        for patient in range(8):
            rows.append({"id": f"synthetic_{dataset_index}_{patient}", "dataset": dataset,
                         "group": str(patient % 2), "subtype": str(1 + patient % 2),
                         "biologic": "AntiTNF" if patient % 3 else "VDZ"})
    meta = pd.DataFrame(rows)
    matrices = []
    for prefix, n_features in (("s", 20), ("p", 10)):
        matrix = pd.DataFrame(rng.uniform(.1, 1, size=(len(meta), n_features)), columns=[f"{prefix}{i}" for i in range(n_features)])
        matrix.insert(0, "id", meta.id)
        matrices.append(matrix)
    paths = [directory / name for name in ("meta.tsv", "species.tsv", "pwy.tsv")]
    for frame, path in zip((meta, *matrices), paths):
        frame.to_csv(path, sep="\t", index=False)
    return paths


class PipelineTests(unittest.TestCase):
    def test_training_only_preprocessing(self):
        raw = pd.DataFrame({"a": [1., 2., 4.], "b": [2., 3., 7.], "absent": [0., 0., 0.]}, index=["a", "b", "c"])
        state = pipeline.block_state(raw, "clr", "species")
        self.assertEqual(state["retained_raw_features"], ["a", "b"])
        self.assertEqual(state["pseudocount"], .5)
        before = json.dumps(state, sort_keys=True)
        external = pd.DataFrame({"a": [.001], "b": [100.], "absent": [99.]}, index=["test"])
        pipeline.apply_block(external, state)
        self.assertEqual(json.dumps(state, sort_keys=True), before)
        partial = external.drop(columns="b")
        with self.assertRaises(ValueError):
            pipeline.apply_block(partial, state)
        filled = pipeline.apply_block(partial, state, allow_missing=True)
        explicit = pipeline.apply_block(partial.assign(b=0.), state)
        np.testing.assert_array_equal(filled, explicit)

    def test_duplicate_headers_fail(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "duplicate.tsv"
            path.write_text("id\tx\tx\na\t1\t2\n")
            with self.assertRaises(ValueError):
                pipeline.read_table(path)

    def test_selection_rule(self):
        rows = pd.DataFrame([
            {"mean_fold_AUROC": .800, "min_fold_AUROC": .60, "pooled_AUROC": .70, "n_species": 16, "n_pwy": 6},
            {"mean_fold_AUROC": .795, "min_fold_AUROC": .65, "pooled_AUROC": .69, "n_species": 8, "n_pwy": 4},
            {"mean_fold_AUROC": .789, "min_fold_AUROC": .70, "pooled_AUROC": .75, "n_species": 4, "n_pwy": 2},
        ])
        selected = pipeline.select_candidates(rows)
        self.assertEqual(selected.n_species, 8)
        self.assertEqual(selected.n_pwy, 4)
        self.assertEqual(len(pipeline.REPRESENTATIONS) * len(pipeline.COUNTS) * len(pipeline.SCREEN_MODELS), 336)

    def test_ci_and_citl(self):
        estimates, ci = diagnostics.classification_intervals(22, 2, 11, 17)
        self.assertAlmostEqual(estimates["NPV"], 11 / 28)
        self.assertAlmostEqual(ci["NPV"][0], .2356568654157956)
        _, example = diagnostics.classification_intervals(77, 44, 702, 10)
        self.assertEqual(tuple(round(value, 3) for value in example["F1"]), (.669, .801))
        _, undefined = diagnostics.classification_intervals(0, 0, 0, 0)
        self.assertTrue(all(np.isnan(value) for value in undefined["F1"]))
        y = np.array([0, 1, 1, 1])
        result = diagnostics.citl(y, np.repeat(.5, 4))
        self.assertAlmostEqual(result["CITL"], np.log(3))
        self.assertAlmostEqual(diagnostics.citl(y, np.repeat(.75, 4))["CITL"], 0.)

    def test_end_to_end_synthetic_only(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            paths = synthetic_tables(directory)
            config = pipeline.read_config(ROOT / "configs/locked_v48.json")
            config["spec"].update(n_species=2, n_pwy=1)
            config["spec"]["params"].update(n_estimators=8, max_depth=2)
            config_path = directory / "config.json"
            pipeline.write_json(config_path, config)
            common = {"meta": paths[0], "species": paths[1], "pwy": paths[2], "expected_n": 40, "config": config_path}
            metadata, species, pwy = pipeline.public_data(SimpleNamespace(**common), clinical=True)
            for _, _, train, test in pipeline.folds(metadata):
                self.assertFalse(set(train.id) & set(test.id))
                self.assertFalse(set(train.dataset) & set(test.dataset))
            pipeline.run_oof(SimpleNamespace(**common, output=directory / "oof"))
            cutoffs = directory / "oof/public_oof_thresholds.json"
            pipeline.run_fit(SimpleNamespace(**common, cutoffs=cutoffs, output=directory / "models"))
            meta = pd.read_csv(paths[0], sep="\t", dtype=str)
            external_path = directory / "external.tsv"
            meta.to_csv(external_path, sep="\t", index=False)
            predict = {"meta": external_path, "species": paths[1], "pwy": paths[2], "models": directory / "models",
                       "cutoffs": directory / "models/public_oof_thresholds.json", "trust_model_files": True,
                       "allow_missing_microbial_columns": False}
            pipeline.run_predict(SimpleNamespace(**predict, output=directory / "predict"))
            before = pd.read_csv(directory / "predict/external_predictions.csv", float_precision="round_trip")
            # Outcome inversion must not affect prediction mode.
            meta["group"] = (1 - meta.group.astype(int)).astype(str)
            meta.to_csv(external_path, sep="\t", index=False)
            pipeline.run_predict(SimpleNamespace(**predict, output=directory / "predict_flipped_labels"))
            after = pd.read_csv(directory / "predict_flipped_labels/external_predictions.csv", float_precision="round_trip")
            # Parallel forest summation can differ in the last floating-point bit.
            np.testing.assert_allclose(before.probability, after.probability, rtol=0, atol=1e-12)
            np.testing.assert_array_equal(before.predicted_response, after.predicted_response)
            self.assertNotIn("true_response", before)
            # Restore labels only for the evaluation smoke test.
            meta["group"] = (1 - meta.group.astype(int)).astype(str)
            meta.to_csv(external_path, sep="\t", index=False)
            evaluation = SimpleNamespace(predictions=directory / "predict/external_predictions.csv", meta=external_path,
                                         cutoffs=predict["cutoffs"])
            diagnostics.evaluate_external(evaluation, pipeline.load_cutoffs(predict["cutoffs"]), pipeline.new_output(directory / "evaluation"))
            audit = json.loads((directory / "evaluation/evaluation_audit.json").read_text())
            self.assertFalse(audit["diagnostic_CITL_applied_to_predictions"])
            self.assertEqual(audit["prediction_model_fits"], 0)
            self.assertTrue((directory / "evaluation/microbiome_calibration_quantile4.png").is_file())
            with self.assertRaises(FileExistsError):
                pipeline.new_output(directory / "oof")

    def test_cli_dry_run_does_not_read_data(self):
        result = subprocess.run([sys.executable, str(ROOT / "prediction_pipeline.py"), "screen",
                                 "--meta", "not_available.tsv", "--species", "not_available.tsv",
                                 "--pwy", "not_available.tsv", "--output", "not_created"],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Check only", result.stdout)


if __name__ == "__main__":
    unittest.main()
